import { useState, useEffect } from 'react';
import Accordion from 'react-bootstrap/Accordion';
import getData from '../assets/utils/getData';

const Employment = () => {
    const [loaded, setLoaded] = useState(false);
    const [employmentObj, setEmploymentObj] = useState();

    useEffect(() => {
        getData('employment/')
            .then((json) => {
                console.log('employment data: ', json);
                setEmploymentObj(json);
                setLoaded(true);
            })
    }, []);

    if (!loaded) return <h1>Loading Employment Data...</h1>;

    return (
        <div className='Employment'>
            <div className='degreeTypeTitle'>
                <h2>{employmentObj.introduction.title}</h2>
            </div>
            
            <Accordion>
                {employmentObj.introduction.content.map((section, index) => (
                    <Accordion.Item eventKey={index.toString()} key={index}>
                        <Accordion.Header>{section.title}</Accordion.Header>
                        <Accordion.Body>
                            <p>{section.description}</p>
                        </Accordion.Body>
                    </Accordion.Item>
                ))}
            </Accordion>
        </div>
    );
}

export default Employment;